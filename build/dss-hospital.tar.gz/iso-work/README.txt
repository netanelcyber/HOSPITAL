================================================================================
  Distributed SharePoint System - Hospital Edition
================================================================================

QUICK START:
1. Mount ISO in VirtualBox
2. Boot and install Ubuntu 22.04 server
3. After boot, run: tar -xzf dss-system.tar.gz && cd dss && ./install.sh
4. Access at: http://<ip>:3000

SYSTEM CONTENTS:
- Complete DSS application (Docker-ready)
- Configuration files
- Documentation
- Installation scripts
- Source code

FEATURES:
✓ Document Management (nested folders)
✓ PACS Medical Imaging
✓ FHIR Healthcare Standards
✓ Real-time Notifications
✓ VM Orchestration
✓ HIPAA Compliance
✓ Security Gateway
✓ Full Audit Logging

REQUIREMENTS:
- VirtualBox 7.0+
- 4GB+ RAM
- 20GB+ disk space

DEFAULT PORTS:
- API Server: 3000
- PACS DICOM: 11112
- PostgreSQL: 5432
- Redis: 6379
- MinIO: 9000/9001

SETUP:
1. Extract: tar -xzf dss-vbox-package.tar.gz
2. Start: cd dss-vbox-package && ./scripts/start.sh
3. Verify: curl http://localhost:3000/health

More info: See docs/README.md and SETUP-VBOX.md

================================================================================
