#!/bin/bash
set -e

echo "Installing Distributed SharePoint System..."

# Update system
sudo apt-get update
sudo apt-get upgrade -y

# Install Docker
sudo apt-get install -y docker.io docker-compose

# Add current user to docker group
sudo usermod -aG docker $USER

# Create DSS directory
mkdir -p ~/dss-system
cd ~/dss-system

# Extract package if not already extracted
if [ ! -d "dss-vbox-package" ]; then
  if [ -f "dss-vbox-package.tar.gz" ]; then
    tar -xzf dss-vbox-package.tar.gz
  else
    echo "No package found. Please copy dss-vbox-package.tar.gz to this directory."
    exit 1
  fi
fi

# Start services
cd dss-vbox-package
./scripts/start.sh

echo "Installation complete!"
echo "Access at: http://localhost:3000"

