#!/bin/bash

echo "=========================================="
echo "Distributed SharePoint System - Startup"
echo "=========================================="

# Check Docker
if ! command -v docker &> /dev/null; then
  echo "Error: Docker not installed"
  echo "Install Docker from: https://docs.docker.com/get-docker/"
  exit 1
fi

# Check Docker Compose
if ! command -v docker-compose &> /dev/null; then
  echo "Error: Docker Compose not installed"
  exit 1
fi

cd "$(dirname "$0")/../system"

# Load Docker image
if [ -f "../docker/dss-system.tar.gz" ]; then
  echo "Loading Docker image..."
  docker load -i ../docker/dss-system.tar.gz
fi

# Start services
echo "Starting services..."
docker-compose up -d

# Wait for services
echo "Waiting for services to start..."
sleep 10

# Check health
echo ""
echo "=========================================="
echo "System Status"
echo "=========================================="
curl -s http://localhost:3000/health | jq . || echo "Service starting..."

echo ""
echo "=========================================="
echo "Access Information"
echo "=========================================="
echo "API Server: http://localhost:3000"
echo "API Docs:   http://localhost:3000/api/v1/status"
echo "PACS Port:  11112"
echo "FHIR API:   http://localhost:3000/api/v1/fhir"
echo ""
echo "Default Credentials:"
echo "  Register new user via: POST /api/v1/auth/register"
echo ""
