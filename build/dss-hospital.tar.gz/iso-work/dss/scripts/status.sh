#!/bin/bash
cd "$(dirname "$0")/../system"
docker-compose ps
echo ""
curl -s http://localhost:3000/health | jq . || echo "Service not responding"
