#!/bin/bash
cd "$(dirname "$0")/../system"
docker-compose down
echo "Services stopped"
