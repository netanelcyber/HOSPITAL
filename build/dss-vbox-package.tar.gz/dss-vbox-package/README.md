# Distributed SharePoint System - VirtualBox Package

Complete deployment package for the Distributed SharePoint System.

## Package Contents

```
dss-vbox-package/
├── docker/
│   └── dss-system.tar.gz          # Docker image
├── system/
│   ├── docker-compose.yml          # Services configuration
│   ├── .env                        # Environment variables
│   └── Dockerfile                  # Image definition
├── scripts/
│   ├── start.sh                    # Start services
│   ├── stop.sh                     # Stop services
│   └── status.sh                   # Check status
├── docs/
│   ├── README.md
│   ├── QUICKSTART.md
│   └── ARCHITECTURE.md
├── SETUP-VBOX.md                   # VirtualBox setup guide
└── README.md                       # This file
```

## Quick Start

### Option 1: Local Docker (Recommended)
```bash
cd system
docker-compose up -d
curl http://localhost:3000/health
```

### Option 2: VirtualBox VM
See SETUP-VBOX.md for detailed instructions

## Services

### API Server (port 3000)
- REST API with JWT authentication
- Document management
- PACS medical imaging
- FHIR healthcare data
- VM orchestration

### PostgreSQL (port 5432)
- Metadata storage
- Document versioning
- User management
- Audit logs

### Redis (port 6379)
- Caching layer
- Notification queue
- Session management

### MinIO Storage (ports 9000, 9001)
- S3-compatible object storage
- Document file storage
- DICOM image storage

## Configuration

Edit `system/.env` before starting:

```bash
# Database
DB_HOST=postgres
DB_USER=postgres
DB_PASSWORD=postgres

# Redis
REDIS_HOST=redis
REDIS_PORT=6379

# Storage
S3_ENDPOINT=http://minio:9000
S3_ACCESS_KEY=minioadmin
S3_SECRET_KEY=minioadmin

# Features
PACS_ENABLED=true
FHIR_ENABLED=false  # Set to true for healthcare features
```

## Networking

### Docker Network
```
dss-network (bridge)
├── dss-api (3000)
├── postgres (5432)
├── redis (6379)
└── minio (9000, 9001)
```

### VirtualBox Network
- **Bridged**: VM on same network as host
- **NAT**: VM accessible via port forwarding

## Security

- JWT-based authentication
- Role-based access control
- Rate limiting (100 req/15 min)
- DDoS protection
- TLS/HTTPS support
- API gateway with security headers

## Performance

- 1000+ concurrent users
- <100ms API response time
- <50ms notification latency
- 500MB+ file upload support
- 1GB+ DICOM study support

## Monitoring

```bash
# Check service status
./scripts/status.sh

# View logs
docker-compose logs -f

# Resource usage
docker stats

# Security status
curl http://localhost:3000/security/status | jq .
```

## Troubleshooting

### Services won't start
```bash
# Check Docker
docker ps
docker-compose ps

# View logs
docker-compose logs dss-api
```

### Database issues
```bash
# Access PostgreSQL
docker-compose exec postgres psql -U postgres

# Reset database
docker-compose down -v
docker-compose up -d
```

## Support

- **Docs**: See `/docs` directory
- **API**: GET /health for health check
- **Logs**: `docker-compose logs`
- **GitHub**: netanelcyber/HOSPITAL

