# Distributed SharePoint System - VirtualBox Setup

## Prerequisites
- VirtualBox 7.0+
- 4GB+ RAM available
- 30GB+ disk space
- Linux host with Docker support

## Installation Steps

### 1. Create VirtualBox VM

```bash
# Create VM
VBoxManage createvm \
  --name "DSS-Hospital" \
  --ostype "Linux_64" \
  --register

# Configure resources
VBoxManage modifyvm "DSS-Hospital" \
  --cpus 4 \
  --memory 8192 \
  --vram 128 \
  --nic1 bridged \
  --bridgeadapter1 eth0

# Create disk
VBoxManage createmedium \
  --filename ~/VirtualBox\ VMs/DSS-Hospital/disk.vdi \
  --size 50000 \
  --format VDI
```

### 2. Install Base OS

Use Ubuntu 22.04 server ISO or minimal Linux image

### 3. Deploy Application

```bash
# Copy package to VM
scp -r dss-vbox-package/ ubuntu@<vm-ip>:~/

# SSH into VM
ssh ubuntu@<vm-ip>

# Run startup script
cd dss-vbox-package
./scripts/start.sh

# Verify
./scripts/status.sh
```

### 4. Access Services

- **API**: http://<vm-ip>:3000/api/v1
- **PACS**: <vm-ip>:11112
- **FHIR**: http://<vm-ip>:3000/api/v1/fhir

## Networking

### Bridged Mode (Recommended)
- VM gets IP from host network
- Accessible from host and other VMs
- Best for production testing

### NAT Mode (Development)
- VM accessible only from host
- Port forwarding required
- Simpler but limited access

## Port Forwarding (if using NAT)

```bash
VBoxManage modifyvm "DSS-Hospital" \
  --natpf1 "http,tcp,,3000,,3000" \
  --natpf1 "pacs,tcp,,11112,,11112" \
  --natpf1 "ssh,tcp,,2222,,22"
```

## Troubleshooting

### VM won't start
- Check disk space (50GB minimum)
- Verify CPU/memory allocation
- Check VirtualBox logs

### Services won't start
- Check Docker installation
- Verify image loaded: `docker images`
- Check logs: `docker-compose logs`

### Can't connect to API
- Check network configuration
- Verify firewall settings
- Check port forwarding rules

## Performance Optimization

### Increase Resources
```bash
VBoxManage modifyvm "DSS-Hospital" \
  --cpus 8 \
  --memory 16384
```

### Enable 3D Acceleration
```bash
VBoxManage modifyvm "DSS-Hospital" \
  --accelerate3d on
```

### Nested Virtualization
```bash
VBoxManage modifyvm "DSS-Hospital" \
  --nested-hw-virt on
```

## Backup & Restore

### Create Snapshot
```bash
VBoxManage snapshot "DSS-Hospital" take "initial-setup"
```

### Restore Snapshot
```bash
VBoxManage snapshot "DSS-Hospital" restore "initial-setup"
```

### Export VM
```bash
VBoxManage export "DSS-Hospital" \
  --output DSS-Hospital.ova
```

